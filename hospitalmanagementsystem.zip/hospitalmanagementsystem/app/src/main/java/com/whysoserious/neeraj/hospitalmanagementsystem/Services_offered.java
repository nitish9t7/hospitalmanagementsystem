package com.whysoserious.neeraj.hospitalmanagementsystem;

import android.database.Cursor;
import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * Created by Neeraj on 14-Apr-16.
 */
public class Services_offered extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.services_offered);

    }
}
